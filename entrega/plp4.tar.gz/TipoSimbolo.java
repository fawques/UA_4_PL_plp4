public enum TipoSimbolo{
	clase,local,campo,argumento,metodo,constructor;
}